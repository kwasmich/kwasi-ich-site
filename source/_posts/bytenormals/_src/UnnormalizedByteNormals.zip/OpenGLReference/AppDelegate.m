//
//  AppDelegate.m
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 13.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [super dealloc];
}

#pragma mark --- NSApplicationDelegate Protocol Reference ---
	
- (void)applicationDidFinishLaunching: (NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed: (NSApplication *)theApplication {
    return YES;
}

@end
