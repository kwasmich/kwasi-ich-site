//
//  OpenGLCore.c
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 14.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "OpenGLCore.h"

#include "Math3D.h"

#include "Model3D.h"

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


// p.35

// TODO :
// test half-float
// test fixed
// try to pack normals in unnormalized 3 byte (normalize in shader)
// try to pack normals and tangent in unnormalized 4 byte - is it even possible? (normalize and compute in shader)

enum uniforms_t {
    UNIFORM_MODEL_MATRIX,
    UNIFORM_VIEW_MATRIX,
    UNIFORM_PROJECTION_MATRIX,
    UNIFORM_NORMAL_MATRIX,
    UNIFORM_EC_LIGHT_POSITION,
    UNIFORM_COLOR,
    NUM_UNIFORMS
};


enum attributes_t {
    ATTRIB_POSITION,
    ATTRIB_NORMAL,
    ATTRIB_COLOR,
    NUM_ATTRIBS
};


static Model model;

static GLuint shaderProgram;
static GLuint uniformLocations[NUM_UNIFORMS];
static GLuint attribLocations[NUM_ATTRIBS];

static GLuint buffers[3];


GLbyte* bNormal1;
GLbyte* bNormal2;


void init() {
    // Per-Fragment Operations
    
    // Scissor Test
    //glEnable( GL_SCISSOR_TEST );
    //glScissor( 0, 0, 640, 480 ); // limits drawing to the designated area in screen-space
    
    // Multisample Fragment Operations
    //glEnable( GL_SAMPLE_ALPHA_TO_COVERAGE );
    //glEnable( GL_SAMPLE_COVERAGE );
    //glSampleCoverage(<#GLclampf value#>, <#GLboolean invert#>);
    
    // Stencil Test
    //glEnable( GL_STENCIL_TEST );
    //glStencilFunc(<#GLenum func#>, <#GLint ref#>, <#GLuint mask#>);
    //glStencilFuncSeparate(<#GLenum face#>, <#GLenum func#>, <#GLint ref#>, <#GLuint mask#>);
    //glStencilOp(<#GLenum fail#>, <#GLenum zfail#>, <#GLenum zpass#>);
    //glStencilOpSeparate(<#GLenum face#>, <#GLenum fail#>, <#GLenum zfail#>, <#GLenum zpass#>);
    
    // Depth Buffer Test
    glEnable( GL_DEPTH_TEST );
    glDepthFunc( GL_LEQUAL );
    
    // Blending
    glEnable( GL_BLEND );
    //glBlendEquation(<#GLenum mode#>);
    //glBlendEquationSeparate(<#GLenum modeRGB#>, <#GLenum modeAlpha#>);
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    //glBlendFuncSeparate(<#GLenum srcRGB#>, <#GLenum dstRGB#>, <#GLenum srcAlpha#>, <#GLenum dstAlpha#>);
    //glBlendColor(<#GLclampf red#>, <#GLclampf green#>, <#GLclampf blue#>, <#GLclampf alpha#>);
    
    // Dithering
    //glEnable( GL_DITHER );
    
    
    
    // Whole Framebuffer Operations
    
    // Fine Control of Buffer Updates
    glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );
    glDepthMask( GL_TRUE );
    //glStencilMask(<#GLuint mask#>);
    //glStencilMaskSeparate(<#GLenum face#>, <#GLuint mask#>);
    
    // Clearing the Buffers
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );
    glClearColor( 0.4f, 0.5f, 0.7f, 0.0f );
    glClearColor( 0, 0, 0, 0 );
    glClearDepth( 1.0f );
    //glClearStencil(<#GLint s#>);
    
    
    
    // Rasterization
    glPointSize( 1 ); //deprecated
    glLineWidth( 1 );
    glFrontFace( GL_CCW );
    glCullFace( GL_BACK );
    glEnable( GL_CULL_FACE );
    //glPolygonOffset(<#GLfloat factor#>, <#GLfloat units#>);
    //glEnable( GL_POLYGON_OFFSET_FILL );
    
    loadShader();
    
    GLint maxVertexAttribs = 0;
    //GLint maxVertexUniformVectors = 0;
    //GLint maxVaryingVectors = 0;
    GLint maxVertexTextureImageUnits = 0;
    GLint maxTextureImageUnits = 0;
    GLint maxCombinedTextureImageUnits = 0;
    GLint sampleBuffers = 0;
    GLint samples = 0;
    GLint aliasedPointSizeRange = 0;
    //GLboolean shaderCompiler = GL_FALSE;
    //GLint numShaderBinaryFormats = 0;
    //GLint maxElemetIndex = 0;
    GLint maxElementsIndices = 0;
    GLint maxElementsVertices = 0;
    glGetIntegerv( GL_MAX_VERTEX_ATTRIBS, &maxVertexAttribs );
    //glGetIntegerv( GL_MAX_VERTEX_UNIFORM_VECTORS, &maxVertexUniformVectors );
    //glGetIntegerv( GL_MAX_VARYING_VECTORS, &maxVaryingVectors );
    glGetIntegerv( GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS, &maxVertexTextureImageUnits );
    glGetIntegerv( GL_MAX_TEXTURE_IMAGE_UNITS, &maxTextureImageUnits );
    glGetIntegerv( GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &maxCombinedTextureImageUnits );
    glGetIntegerv( GL_SAMPLE_BUFFERS, &sampleBuffers );
    glGetIntegerv( GL_SAMPLES, &samples );
    glGetIntegerv( GL_ALIASED_POINT_SIZE_RANGE, &aliasedPointSizeRange );   // FIX ME: is this correct?
    //glGetBooleanv( GL_SHADER_COMPILER, &shaderCompiler );
    //glGetIntegerv( GL_NUM_SHADER_BINARY_FORMATS, &numShaderBinaryFormats );
    //glGetIntegerv( GL_MAX_ELEMENT_INDEX, &maxElemetIndex );
    glGetIntegerv( GL_MAX_ELEMENTS_INDICES, &maxElementsIndices); // reduced performance if outside bounds
    glGetIntegerv( GL_MAX_ELEMENTS_VERTICES, &maxElementsVertices ); // reduced performance if outside bounds
    printf( "GL_MAX_VERTEX_ATTRIBS = %i\n", maxVertexAttribs );
    printf( "GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS = %i\n", maxVertexTextureImageUnits );
    printf( "GL_MAX_TEXTURE_IMAGE_UNITS = %i\n", maxTextureImageUnits );
    printf( "GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS = %i\n", maxCombinedTextureImageUnits );
    printf( "GL_SAMPLE_BUFFERS = %i\n", sampleBuffers );
    printf( "GL_SAMPLES = %i\n", samples );
    printf( "GL_ALIASED_POINT_SIZE_RANGE = %i\n", aliasedPointSizeRange );
    printf( "GL_MAX_ELEMENTS_INDICES = %i\n", maxElementsIndices );
    printf( "GL_MAX_ELEMENTS_VERTICES = %i\n", maxElementsVertices );
    assert( NUM_UNIFORMS <= 100 );
    assert( NUM_ATTRIBS <= maxVertexAttribs );
    
    
    model = loadModel( "./OpenGLReference.app/Contents/Resources/Assets/Model/bimba.off" );
    
    // init server storage
    if ( true ) {
        glGenBuffers( 3, buffers );
        
        // vertex array static initialization
        glBindBuffer( GL_ARRAY_BUFFER, buffers[0] );
        glBufferData( GL_ARRAY_BUFFER, model.vertexCount * sizeof(vec3), model.vertices, GL_STATIC_DRAW );
        
        // vertex array dynamic modification
        glBindBuffer( GL_ARRAY_BUFFER, buffers[1] );
        glBufferData( GL_ARRAY_BUFFER, model.vertexCount * sizeof(vec3), NULL, GL_STATIC_DRAW );
        glBufferSubData( GL_ARRAY_BUFFER, 0, model.vertexCount * sizeof(vec3), model.normals );
        
        // index array
        glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, buffers[2] );
        glBufferData( GL_ELEMENT_ARRAY_BUFFER, model.indexCount * sizeof(unsigned int), model.indices, GL_STATIC_DRAW );
        
        // unbind buffer objects
        glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );
        glBindBuffer( GL_ARRAY_BUFFER, 0 );
    }
    
    bNormal1 = malloc( 256 * 256 * 256 * 3 * sizeof(GLbyte) );
    bNormal2 = malloc( 256 * 256 * 256 * 3 * sizeof(GLbyte) );
    
    for ( int z = 0; z < 256; z++ ) {
        for ( int y = 0; y < 256; y++ ) {
            for ( int x = 0; x < 256; x++ ) {
                bNormal1[(z * 256 * 256 + y * 256 + x) * 3 + 0] = x;
                bNormal1[(z * 256 * 256 + y * 256 + x) * 3 + 1] = y;
                bNormal1[(z * 256 * 256 + y * 256 + x) * 3 + 2] = z;
                
                vec3 tmp = {{x - 128, y - 128, z - 128}};
                tmp = normalize( tmp );
                
                bNormal2[(z * 256 * 256 + y * 256 + x) * 3 + 0] = 127 * tmp.x;
                bNormal2[(z * 256 * 256 + y * 256 + x) * 3 + 1] = 127 * tmp.y;
                bNormal2[(z * 256 * 256 + y * 256 + x) * 3 + 2] = 127 * tmp.z;
            }
        }
    }
}



void cleanUp() {
    // unbind and destroy buffer objects
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );
    glBindBuffer( GL_ARRAY_BUFFER, 0 );
    glDeleteBuffers( 3, buffers );
    buffers[0] = 0;
    buffers[1] = 0;
    buffers[2] = 0;
}



void reshape( const GLsizei in_WIDTH, const GLsizei in_HEIGHT ) {
    //printf( "reshape( %i, %i )\n", in_WIDTH, in_HEIGHT );
    
    // Viewport and Clipping
    // Controlling the Viewport
    glDepthRange( 0, 1 );
    glViewport( 0, 0, in_WIDTH, in_HEIGHT );
}



void draw( const float in_TIME ) {
    error();
    //printf( "drawing…\n" );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    
    glUseProgram( shaderProgram );
    
    error();
    
    assert( uniformLocations[UNIFORM_MODEL_MATRIX] != -1U );
    assert( uniformLocations[UNIFORM_VIEW_MATRIX] != -1U );
    assert( uniformLocations[UNIFORM_PROJECTION_MATRIX] != -1U );
    assert( uniformLocations[UNIFORM_NORMAL_MATRIX] != -1U );
    assert( uniformLocations[UNIFORM_EC_LIGHT_POSITION] != -1U );
    assert( attribLocations[ATTRIB_COLOR] != -1U );
    assert( attribLocations[ATTRIB_POSITION] != -1U );
    assert( attribLocations[ATTRIB_NORMAL] != -1U );
    
    vec3 translation = {{0, 0, -4}};
    //vec3 translation = {{0, 0, 0.5f * sinf(in_TIME * 0.1f)}};
    mat4 modelMatrix = mat4MakeWithDiagonal( 1 );
    modelMatrix = mat4MakeRotateY( in_TIME * 0.1f);
    
    mat4 viewMatrix = mat4MakeTranslate( translation );
    mat4 projectionMatrix = mat4MakeFrustum( -0.048f, 0.048f, -0.03f, 0.03f, 0.1f, 10 );
    //projectionMatrix = mat4MakeOrtho( -1.67, 1.76, -1.1, 1.1, 0, 10 );
    mat4 modelViewMatrix = mul(viewMatrix, modelMatrix);
    mat3 normalMatrix0 = mat3FromMat4(modelViewMatrix);
    mat3 normalMatrix = inverseTranspose(normalMatrix0);
    
    //vec3 ecLightPos = {{0.5f, 0.3f, -0.5f }};
    vec3 ecLightPos = {{ sin(in_TIME) * 0.5f, cos(0.3f * in_TIME) * 0.3f, -0.5f }};
    
    glUniformMatrix4fv( uniformLocations[UNIFORM_MODEL_MATRIX], 1, GL_FALSE, modelMatrix.m );
    glUniformMatrix4fv( uniformLocations[UNIFORM_VIEW_MATRIX], 1, GL_FALSE, viewMatrix.m );
    glUniformMatrix4fv( uniformLocations[UNIFORM_PROJECTION_MATRIX], 1, GL_FALSE, projectionMatrix.m );
    glUniformMatrix3fv( uniformLocations[UNIFORM_NORMAL_MATRIX], 1, GL_FALSE, normalMatrix.m );
    glUniform3fv( uniformLocations[UNIFORM_EC_LIGHT_POSITION], 1, ecLightPos.v );
    
    error();
    
    // debug
    if ( false ) {
        glDisableVertexAttribArray( attribLocations[ATTRIB_COLOR] );
        glVertexAttrib3f( attribLocations[ATTRIB_NORMAL], 0, 0, 1 );
        glDisableVertexAttribArray( attribLocations[ATTRIB_NORMAL] );
        glEnableVertexAttribArray( attribLocations[ATTRIB_POSITION] );
        
//        glVertexAttrib3f( attribLocations[ATTRIB_COLOR], 0, 1, 0 );
//        glVertexAttrib3f( attribLocations[ATTRIB_NORMAL], -1, 1, -1 );
//        glVertexAttribPointer( attribLocations[ATTRIB_VERTEX], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), model.vertices );        
//        glDrawElements( GL_LINES, model.indexCountLine, GL_UNSIGNED_SHORT, model.indicesLine );
        
        glVertexAttrib3f( attribLocations[ATTRIB_COLOR], 1, 0, 0 );
        glVertexAttrib3f( attribLocations[ATTRIB_NORMAL], 1, -1, -1 );
        glVertexAttribPointer( attribLocations[ATTRIB_POSITION], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), model.debugNormals );
        glDrawArrays( GL_LINES, 0, model.vertexCount * 2 );
    }
    
    if ( true ) {
        // constant attributes
        glVertexAttrib3f( attribLocations[ATTRIB_COLOR], 1, 1, 1 );
        glDisableVertexAttribArray( attribLocations[ATTRIB_COLOR] );
        glVertexAttrib3f( attribLocations[ATTRIB_NORMAL], 0, 0, 1 );
        glDisableVertexAttribArray( attribLocations[ATTRIB_NORMAL] );
        
        glVertexAttribPointer( attribLocations[ATTRIB_POSITION], 3, GL_BYTE, GL_FALSE, 3 * sizeof(GLbyte), bNormal1 );
        glEnableVertexAttribArray( attribLocations[ATTRIB_POSITION] );
        
        glDrawArrays( GL_POINTS, 0, 256 * 256 * 256 );
    }
    
    // draw from client storage
    if ( false ) {
        // constant attributes
        glVertexAttrib3f( attribLocations[ATTRIB_COLOR], 1, 0.7, 0.3 );
        glDisableVertexAttribArray( attribLocations[ATTRIB_COLOR] );
        
        // per vertex attributes
        //glVertexAttribPointer( attribLocations[ATTRIB_COLOR], 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), colors );
        //glEnableVertexAttribArray( attribLocations[ATTRIB_COLOR] );
        
        glVertexAttribPointer( attribLocations[ATTRIB_POSITION], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), model.vertices );
        //glVertexAttribPointer( attribLocations[ATTRIB_POSITION], 3, GL_HALF_FLOAT, GL_FALSE, 3 * sizeof(GLhalf), model.halfVertices );
        glEnableVertexAttribArray( attribLocations[ATTRIB_POSITION] );
        
        glVertexAttribPointer( attribLocations[ATTRIB_NORMAL], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), model.normals );
        //glVertexAttribPointer( attribLocations[ATTRIB_NORMAL], 3, GL_BYTE, GL_FALSE, 3 * sizeof(GLbyte), model.byteNormals );
        glEnableVertexAttribArray( attribLocations[ATTRIB_NORMAL] );
        
        //glDrawArrays( GL_POINTS, 0, model.vertexCount );
        glDrawElements( GL_TRIANGLES, model.indexCount, GL_UNSIGNED_SHORT, model.indices );
        //glDrawElements( GL_LINES, model.indexCountLine, GL_UNSIGNED_SHORT, model.indicesLine );
    }
        
    // draw from server storage
    if ( false ) {
        // constant attributes
        glVertexAttrib3f( attribLocations[ATTRIB_COLOR], 0, 1, 0 );
        glDisableVertexAttribArray( attribLocations[ATTRIB_COLOR] );
        
        glBindBuffer( GL_ARRAY_BUFFER, buffers[0] );
        glVertexAttribPointer( attribLocations[ATTRIB_POSITION], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0 );
        glEnableVertexAttribArray( attribLocations[ATTRIB_POSITION] );
        
        // per vertex attributes
        glBindBuffer( GL_ARRAY_BUFFER, buffers[1] );
        glVertexAttribPointer( attribLocations[ATTRIB_NORMAL], 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0 );
        glEnableVertexAttribArray( attribLocations[ATTRIB_NORMAL] );
        
        glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, buffers[2] );
        //glDrawArrays( GL_POINTS, 0, model.vertexCount );
        glDrawElements( GL_TRIANGLES, model.indexCount, GL_UNSIGNED_SHORT, 0 );
        //glDrawElements( GL_LINES, model.indexCountLine, GL_UNSIGNED_SHORT, model.indicesLine );
    }
    
    
    // instanced rendering
    // uses uniform buffer for instance uniforms
    //glVertexAttribDivisorARB(<#GLuint index#>, <#GLuint divisor#>);
    //glDrawElementsInstancedARB(<#GLenum mode#>, <#GLsizei count#>, <#GLenum type#>, <#const GLvoid *indices#>, <#GLsizei primcount#>)
    //glDrawRangeElements(<#GLenum mode#>, <#GLuint start#>, <#GLuint end#>, <#GLsizei count#>, <#GLenum type#>, <#const GLvoid *indices#>)
    //glDrawArraysInstancedARB(<#GLenum mode#>, <#GLint first#>, <#GLsizei count#>, <#GLsizei primcount#>)
    //glBindBufferRange(<#GLenum target#>, <#GLuint index#>, <#GLuint buffer#>, <#GLintptr offset#>, <#GLsizeiptr size#>)
    //glBindBufferBase(<#GLenum target#>, <#GLuint index#>, <#GLuint buffer#>)
    
    // primitive restart (e.g. restart line loops whenever the index is called)
    //glEnable(GL_PRIMITIVE_RESTART_FIXED_INDEX);
    
    error();
}



void loadShader() {
    //char buff[1024];
    //getcwd( buff, 1024 );
    //printf( "%s\n", buff );
    
    GLuint vertShaderObject = loadShaderObject( "./OpenGLReference.app/Contents/Resources/Assets/Shader/Shader.vs", GL_VERTEX_SHADER );
    GLuint fragShaderObject = loadShaderObject( "./OpenGLReference.app/Contents/Resources/Assets/Shader/Shader.fs", GL_FRAGMENT_SHADER );
    
    shaderProgram = glCreateProgram();
    assert( shaderProgram != 0 );
    
    glAttachShader( shaderProgram, vertShaderObject );
    glAttachShader( shaderProgram, fragShaderObject );
    glLinkProgram( shaderProgram );
    
    GLint linkStatus = 0;
    glGetProgramiv( shaderProgram, GL_LINK_STATUS, &linkStatus );
    
    // check the link status
    GLsizei infoLogLength = 0;
    glGetProgramiv( shaderProgram, GL_INFO_LOG_LENGTH, &infoLogLength );
    infoLogLength++;
    GLchar* infoLog = malloc( sizeof( GLchar ) * infoLogLength );
    glGetProgramInfoLog( shaderProgram, infoLogLength, &infoLogLength, infoLog );
    printf( "%s", infoLog );
    free( infoLog );
    
    assert( linkStatus == GL_TRUE );
    
    glDeleteShader( vertShaderObject );
    glDeleteShader( fragShaderObject );
    vertShaderObject = 0;
    fragShaderObject = 0;
    
    // validate shader program
    glValidateProgram( shaderProgram );
    GLint validateStatus = 0;
    glGetProgramiv( shaderProgram, GL_VALIDATE_STATUS, &validateStatus );
    assert( validateStatus == GL_TRUE );
    
    infoLogLength = 0;
    glGetProgramiv( shaderProgram, GL_INFO_LOG_LENGTH, &infoLogLength );
    infoLogLength++;
    infoLog = malloc( sizeof( GLchar ) * infoLogLength );
    glGetProgramInfoLog( shaderProgram, infoLogLength, &infoLogLength, infoLog );
    printf( "%s", infoLog );
    free( infoLog );
    
    // check the uniforms
    GLint activeUniforms = 0;
    GLint activeUniformsMaxLength = 0;
    glGetProgramiv( shaderProgram, GL_ACTIVE_UNIFORMS, &activeUniforms );
    glGetProgramiv( shaderProgram, GL_ACTIVE_UNIFORM_MAX_LENGTH, &activeUniformsMaxLength );
    activeUniformsMaxLength++;
    GLint activeUniformLength = 0;
    GLint activeUniformSize = 0;
    GLenum activeUniformType = 0;
    GLchar* activeUniform = malloc( sizeof( GLchar ) * activeUniformsMaxLength );
    
    for ( GLint i = 0; i < activeUniforms; i++ ) {
        glGetActiveUniform( shaderProgram, i, activeUniformsMaxLength, &activeUniformLength, &activeUniformSize, &activeUniformType, activeUniform );
        
        switch ( activeUniformType ) {
            case GL_FLOAT:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT", activeUniformSize );
                break;
                
            case GL_FLOAT_VEC2:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_VEC2", activeUniformSize );
                break;
                
            case GL_FLOAT_VEC3:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_VEC3", activeUniformSize );
                break;
                
            case GL_FLOAT_VEC4:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_VEC4", activeUniformSize );
                break;
                
            case GL_INT:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_INT", activeUniformSize );
                break;
                
            case GL_INT_VEC2:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_INT_VEC2", activeUniformSize );
                break;
                
            case GL_INT_VEC3:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_INT_VEC3", activeUniformSize );
                break;
                
            case GL_INT_VEC4:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_INT_VEC4", activeUniformSize );
                break;
                
            case GL_BOOL:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_BOOL", activeUniformSize );
                break;
                
            case GL_BOOL_VEC2:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_BOOL_VEC2", activeUniformSize );
                break;
                
            case GL_BOOL_VEC3:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_BOOL_VEC3", activeUniformSize );
                break;
                
            case GL_BOOL_VEC4:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_BOOL_VEC4", activeUniformSize );
                break;
                
            case GL_FLOAT_MAT2:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_MAT2", activeUniformSize );
                break;
                
            case GL_FLOAT_MAT3:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_MAT3", activeUniformSize );
                break;
                
            case GL_FLOAT_MAT4:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_FLOAT_MAT4", activeUniformSize );
                break;
                
            case GL_SAMPLER_2D:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_SAMPLER_2D", activeUniformSize );
                break;
                
            case GL_SAMPLER_CUBE:
                printf( "%-20s %-15s %i\n", activeUniform, "GL_SAMPLER_CUBE", activeUniformSize );
                break;
                
            default:
                printf( "%-20s %-15s %i\n", activeUniform, "(UNKNOWN)", activeUniformSize );
                break;
        }
    }
    
    free( activeUniform );
    activeUniform = NULL;
    
    // check the attributes
    GLint activeAttributes = 0;
    GLint activeAttributesMaxLength = 0;
    glGetProgramiv( shaderProgram, GL_ACTIVE_ATTRIBUTES, &activeAttributes );
    glGetProgramiv( shaderProgram, GL_ACTIVE_ATTRIBUTE_MAX_LENGTH, &activeAttributesMaxLength );
    activeAttributesMaxLength++;
    GLint activeAttributeLength = 0;
    GLint activeAttributeSize = 0;
    GLenum activeAttributeType = 0;
    GLchar* activeAttribute = malloc( sizeof( GLchar ) * activeAttributesMaxLength );
    
    for ( GLint i = 0; i < activeAttributes; i++ ) {
        glGetActiveAttrib( shaderProgram, i, activeAttributesMaxLength, &activeAttributeLength, &activeAttributeSize, &activeAttributeType, activeAttribute );
        
        switch ( activeAttributeType ) {
            case GL_FLOAT:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT", activeAttributeSize );
                break;
                
            case GL_FLOAT_VEC2:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_VEC2", activeAttributeSize );
                break;
                
            case GL_FLOAT_VEC3:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_VEC3", activeAttributeSize );
                break;
                
            case GL_FLOAT_VEC4:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_VEC4", activeAttributeSize );
                break;
                
            case GL_FLOAT_MAT2:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_MAT2", activeAttributeSize );
                break;
                
            case GL_FLOAT_MAT3:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_MAT3", activeAttributeSize );
                break;
                
            case GL_FLOAT_MAT4:
                printf( "%-20s %-13s %i\n", activeAttribute, "GL_FLOAT_MAT4", activeAttributeSize );
                break;
                
            default:
                printf( "%-20s %-13s %i\n", activeAttribute, "(UNKNOWN)", activeAttributeSize );
                break;
        }
    }
    
    free( activeAttribute );
    activeAttribute = NULL;
        
    // get uniform locations
    uniformLocations[UNIFORM_MODEL_MATRIX] = glGetUniformLocation( shaderProgram, "u_modelMatrix" );
    uniformLocations[UNIFORM_VIEW_MATRIX] = glGetUniformLocation( shaderProgram, "u_viewMatrix" );
    uniformLocations[UNIFORM_PROJECTION_MATRIX] = glGetUniformLocation( shaderProgram, "u_projectionMatrix" );
    uniformLocations[UNIFORM_NORMAL_MATRIX] = glGetUniformLocation( shaderProgram, "u_normalMatrix" );
    uniformLocations[UNIFORM_EC_LIGHT_POSITION] = glGetUniformLocation( shaderProgram, "u_ecLightPos" );
    uniformLocations[UNIFORM_COLOR] = glGetAttribLocation( shaderProgram, "u_color" );
    
    
    // get attribute locations
    attribLocations[ATTRIB_POSITION] = glGetAttribLocation( shaderProgram, "a_position" );
    attribLocations[ATTRIB_NORMAL] = glGetAttribLocation( shaderProgram, "a_normal" );
    //attribLocations[ATTRIB_TANGENT] = glGetAttribLocation( shaderProgram, "a_tangent" );
    //attribLocations[ATTRIB_BI_TANGENT] = glGetAttribLocation( shaderProgram, "a_biTangent" );
    attribLocations[ATTRIB_COLOR] = glGetAttribLocation( shaderProgram, "a_color" );
    //attribLocations[ATTRIB_TEX_COORD] = glGetAttribLocation( shaderProgram, "a_texCoord" );
    
    glUseProgram( shaderProgram );
}



void unloadShader() {
    glUseProgram( 0 );
    glDeleteProgram( shaderProgram );
    shaderProgram = 0;
}



GLuint loadShaderObject( const char* in_FILE_NAME, const GLenum in_SHADER_TYPE ) {
    GLchar* shaderSource = readFile( in_FILE_NAME );
    assert( shaderSource != NULL );
    
    GLuint shaderObject = glCreateShader( in_SHADER_TYPE );
    assert( shaderObject != 0 );
    
    glShaderSource( shaderObject, 1, &shaderSource, NULL );
    glCompileShader( shaderObject );
    
    GLint compileStatus = 0;
    glGetShaderiv( shaderObject, GL_COMPILE_STATUS, &compileStatus );
    
    //if ( compileStatus != GL_TRUE ) {
        GLsizei infoLogLength = 0;
        glGetShaderiv( shaderObject, GL_INFO_LOG_LENGTH, &infoLogLength );
        infoLogLength++;
        GLchar* infoLog = malloc( sizeof( GLchar ) * infoLogLength );
        glGetShaderInfoLog( shaderObject, infoLogLength, &infoLogLength, infoLog );
        printf( "%s", infoLog );
        free( infoLog );
    //}
    
    assert( compileStatus == GL_TRUE );
    
    free( shaderSource );
    shaderSource = NULL;
    return shaderObject;
}



char* readFile( const char* in_FILE_NAME ) {
    char* fileContents = NULL;
    FILE* fileStream = fopen( in_FILE_NAME, "rb" );
    
    if ( !fileStream ) {
        perror( in_FILE_NAME );
        return fileContents;
    }
    
    int err = fseek( fileStream, 0L, SEEK_END );
    assert( err == 0 );
    
    long length = ftell( fileStream );
    rewind( fileStream );
    
    fileContents = malloc( sizeof( char ) * ( length + 1 ) );
    fread( fileContents, sizeof(char), length, fileStream );
    fileContents[length] = 0;
    fclose( fileStream );
    fileStream = NULL;
    return fileContents;
}



void error() {
    GLenum errorCode = glGetError();
    int count = 0;
    
    while ( errorCode != GL_NO_ERROR ) {
        switch ( errorCode ) {
            case GL_INVALID_ENUM:
                fputs( "GL_INVALID_ENUM\n", stderr );
                break;
                                
            case GL_INVALID_VALUE:
                fputs( "GL_INVALID_VALUE\n", stderr );
                break;
                
            case GL_INVALID_OPERATION:
                fputs( "GL_INVALID_OPERATION\n", stderr );
                break;
                
            case GL_INVALID_FRAMEBUFFER_OPERATION:
                fputs( "GL_INVALID_FRAMEBUFFER_OPERATION\n", stderr );
                break;
                
            case GL_OUT_OF_MEMORY:
                fputs( "GL_OUT_OF_MEMORY\n", stderr );
                break;
                
            default:
                fputs( "UNKNOWN GL ERROR!", stderr );
                break;
        }
        
        errorCode = glGetError();
        count++;
    }
    
    assert( count == 0 );
}
