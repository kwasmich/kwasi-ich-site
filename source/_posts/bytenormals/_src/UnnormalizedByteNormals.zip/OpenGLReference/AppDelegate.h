//
//  AppDelegate.h
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 13.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    NSWindow * _window;
}

@property (assign) IBOutlet NSWindow *window;


@end
