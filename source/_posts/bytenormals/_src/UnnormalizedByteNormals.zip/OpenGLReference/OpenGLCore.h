//
//  OpenGLCore.h
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 14.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef OpenGLReference_OpenGLCore_h
#define OpenGLReference_OpenGLCore_h

#include <OpenGL/gl.h>

void init( void );
void cleanUp( void );
void reshape( const GLsizei in_WIDTH, const GLsizei in_HEIGHT );
void draw( const float in_TIME );

void loadShader( void );
void unloadShader( void );
GLuint loadShaderObject( const char* in_FILE_NAME, const GLenum in_SHADER_TYPE );
char* readFile( const char* in_FILE_NAME );

void error( void );

#endif
