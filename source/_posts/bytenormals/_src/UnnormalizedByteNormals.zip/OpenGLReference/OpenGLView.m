//
//  OpenGLView.m
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 14.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OpenGLView.h"

#import "OpenGLCore.h"

#import <iso646.h>


// This is the renderer output callback function
static CVReturn MyDisplayLinkCallback( CVDisplayLinkRef displayLink, const CVTimeStamp* now, const CVTimeStamp* outputTime, CVOptionFlags flagsIn, CVOptionFlags* flagsOut, void* displayLinkContext ) {
    CVReturn result = [(OpenGLView*)displayLinkContext getFrameForTime:outputTime];
    return result;
}



@implementation OpenGLView



- (void)dealloc
{
    cleanUp();
    
    // Stop and release the display link
	CVDisplayLinkStop( displayLink );
    CVDisplayLinkRelease( displayLink );
    displayLink = NULL;
    
    [super dealloc];
}



#pragma mark --- NSOpenGLView Class Reference ---



+ (NSOpenGLPixelFormat*)defaultPixelFormat
{
    NSLog( @"defaultPixelFormat" );
    NSOpenGLPixelFormatAttribute attributes [] = {
        NSOpenGLPFAWindow,
        //NSOpenGLPFAMultisample, //
        NSOpenGLPFASupersample, // mutual exclusive but require SampleBuffers and Samples
        //NSOpenGLPFASampleAlpha, //
        NSOpenGLPFASampleBuffers, 1,
        NSOpenGLPFASamples, 6,
        NSOpenGLPFADoubleBuffer,    // double buffered
        NSOpenGLPFAColorSize, 16,
        NSOpenGLPFADepthSize, 24, // 16 bit depth buffer
        NSOpenGLPFAStencilSize, 8,
        (NSOpenGLPixelFormatAttribute)nil
    };
    return [[[NSOpenGLPixelFormat alloc] initWithAttributes:attributes] autorelease];
}



- (id)initWithFrame: (NSRect)frameRect
{
    // Actually we do not need to implement this method
    // But pixelFormat will return NULL if we don't do this and we require it for CVDisplayLink
    NSLog( @"initWithFrame" );
    NSOpenGLPixelFormat *pixelFormat = [OpenGLView defaultPixelFormat]; 
    
    self = [super initWithFrame: frameRect pixelFormat: pixelFormat];
    
    if ( self ) {
        // Obj-C inits here
    }
    
    return self;
}



- (void)prepareOpenGL
{    
    // Synchronize buffer swaps with vertical refresh rate (VSync)
    GLint swapInt = 1;
    [[self openGLContext] setValues:&swapInt forParameter:NSOpenGLCPSwapInterval];

//	CVDisplayLinkCreateWithActiveCGDisplays( &displayLink );
//	CVDisplayLinkSetOutputCallback( displayLink, &MyDisplayLinkCallback, self );
//	CGLContextObj cglContext = [[self openGLContext] CGLContextObj];
//	CGLPixelFormatObj cglPixelFormat = [[self pixelFormat] CGLPixelFormatObj];
//	CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext( displayLink, cglContext, cglPixelFormat );
       
    init();
    
    [self animationStart];
}



- (void)reshape
{
    NSRect frame = [self frame];
    GLsizei width = ( frame.size.width < 1 ) ? 1 : frame.size.width;
    GLsizei height = ( frame.size.height < 1 ) ? 1 : frame.size.height;
    
    // stopping is required to avoid thread conflicts
    [self animationStop];
    reshape( width, height );
    [self update];
    [self animationStart];
}



#pragma mark --- NSView Class Reference ---



- (void)drawRect: (NSRect)dirtyRect
{
	if ( not CVDisplayLinkIsRunning( displayLink ) ) {
		[self drawAtTime:0];
    }
}



#pragma mark --- NSResponder Class Reference ---



- (BOOL) acceptsFirstResponder
{
    // We want this view to be able to receive key events
    return YES;
}



- (void) keyDown: (NSEvent *)theEvent
{
    NSString * chars = [theEvent characters];
    NSString * chars2 = [theEvent charactersIgnoringModifiers];
    BOOL isRepeat = [theEvent isARepeat];
    unsigned short keyCode = [theEvent keyCode];
    NSUInteger modifiers = [theEvent modifierFlags];
    unichar uchar = 0;
    
    if ( modifiers bitand NSAlphaShiftKeyMask ) {
        NSLog( @"CapsLock" );
    }
    
    if ( modifiers bitand NSShiftKeyMask ) {
        NSLog( @"Shift" );
    }
    
    if ( modifiers bitand NSControlKeyMask ) {
        NSLog( @"Control" );
    }
    
    if ( modifiers bitand NSAlternateKeyMask ) {
        NSLog( @"Alt" );
    }
    
    if ( modifiers bitand NSCommandKeyMask ) {
        NSLog( @"Command" );
    }
    
    if ( modifiers bitand NSNumericPadKeyMask ) {
        NSLog( @"NumPad" );
    }
    
    if ( modifiers bitand NSHelpKeyMask ) {
        NSLog( @"Help" );
    }
    
    if ( modifiers bitand NSFunctionKeyMask ) {
        NSLog( @"Fn" );
    }
    
    if ( [chars2 length] > 0 ) {
        uchar = [chars2 characterAtIndex:0];
    }
    
    if ( not isRepeat ) {
        NSLog( @"DOWN %@ %@ %i %i %x", chars, chars2, isRepeat, keyCode, uchar );
    }
    
    unichar c = [[theEvent charactersIgnoringModifiers] characterAtIndex:0];
    
    switch (c) {
            
            // [Esc] exits full-screen mode
        case 27:
            [self fullscreenToggle];
            break;
            
            // [space] toggles rotation of the globe
        case ' ':
            [self animationToggle];
            break;
            
            // [W] toggles wireframe rendering
        case 'f':
        case 'F':
            [self fullscreenToggle];
            break;
            
        default:
            break;
    }
}



- (void) keyUp: (NSEvent *)theEvent
{
    NSString * chars = [theEvent characters];
    NSString * chars2 = [theEvent charactersIgnoringModifiers];
    BOOL isRepeat = [theEvent isARepeat];
    unsigned short keyCode = [theEvent keyCode];
    NSUInteger modifiers = [theEvent modifierFlags];
    unichar uchar = 0;
    
    if ( modifiers bitand NSAlphaShiftKeyMask ) {
        NSLog( @"CapsLock" );
    }
    
    if ( modifiers bitand NSShiftKeyMask ) {
        NSLog( @"Shift" );
    }
    
    if ( modifiers bitand NSControlKeyMask ) {
        NSLog( @"Control" );
    }
    
    if ( modifiers bitand NSAlternateKeyMask ) {
        NSLog( @"Alt" );
    }
    
    if ( modifiers bitand NSCommandKeyMask ) {
        NSLog( @"Command" );
    }
    
    if ( modifiers bitand NSNumericPadKeyMask ) {
        NSLog( @"NumPad" );
    }
    
    if ( modifiers bitand NSHelpKeyMask ) {
        NSLog( @"Help" );
    }
    
    if ( modifiers bitand NSFunctionKeyMask ) {
        NSLog( @"Fn" );
    }
    
    if ( [chars2 length] > 0 ) {
        uchar = [chars2 characterAtIndex:0];
    }
    
    NSLog( @"UP   %@ %@ %i %i %x", chars, chars2, isRepeat, keyCode, uchar );
}



- (void)flagsChanged:(NSEvent *)theEvent {
    NSUInteger modifiers = [theEvent modifierFlags];
    
    if ( modifiers bitand NSAlphaShiftKeyMask ) {
        NSLog( @"CapsLock" );
    }
    
    if ( modifiers bitand NSShiftKeyMask ) {
        NSLog( @"Shift" );
    }
    
    if ( modifiers bitand NSControlKeyMask ) {
        NSLog( @"Control" );
    }
    
    if ( modifiers bitand NSAlternateKeyMask ) {
        NSLog( @"Alt" );
    }
    
    if ( modifiers bitand NSCommandKeyMask ) {
        NSLog( @"Command" );
    }
    
    if ( modifiers bitand NSNumericPadKeyMask ) {
        NSLog( @"NumPad" );
    }
    
    if ( modifiers bitand NSHelpKeyMask ) {
        NSLog( @"Help" );
    }
    
    if ( modifiers bitand NSFunctionKeyMask ) {
        NSLog( @"Fn" );
    }
}



- (void)scrollWheel:(NSEvent *)theEvent {
    NSLog( @"Scroll : %f %f %f\n", [theEvent deltaX], [theEvent deltaY], [theEvent deltaZ] );
}



#pragma mark --- custom ---



- (CVReturn)getFrameForTime:(const CVTimeStamp*)outputTime
{
    // There is no autorelease pool when this method is called because it will be called from a background thread
	// It's important to create one or you will leak objects
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    CGFloat time = (CGFloat)outputTime->videoTime / (CGFloat)outputTime->videoTimeScale;
    
	// Update the animation
	//CFAbsoluteTime currentTime = CFAbsoluteTimeGetCurrent();
    CGLLockContext([[self openGLContext] CGLContextObj]);
	[[self openGLContext] makeCurrentContext];
	[self drawAtTime:time];	
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
	
	[pool release];
    
    return kCVReturnSuccess;
}



- (void)animationToggle
{
    if ( isAnimationRunning ) {
        [self animationStop];
    } else {
        [self animationStart];
    }
}



- (void)animationStart
{
    if ( displayLink and ( not CVDisplayLinkIsRunning( displayLink ) ) ) {
		CVDisplayLinkStart( displayLink );
        isAnimationRunning = YES;
    }
}



- (void)animationStop
{
    if ( displayLink and ( CVDisplayLinkIsRunning( displayLink ) ) ) {
		CVDisplayLinkStop( displayLink );
        isAnimationRunning = NO;
    }
}



- (void)fullscreenToggle
{
    NSDictionary* options = [NSDictionary dictionaryWithObjectsAndKeys:
                             //[NSNumber numberWithBool:YES], NSFullScreenModeSetting, // deprecated
                             [NSNumber numberWithBool:NO], NSFullScreenModeAllScreens,
                             //[NSNumber numberWithInt:NSMainMenuWindowLevel-1], NSFullScreenModeWindowLevel, // not working
                             //[NSNumber numberWithInt:NSApplicationPresentationDefault], NSFullScreenModeApplicationPresentationOptions,
                             [NSNumber numberWithInt:NSApplicationPresentationAutoHideMenuBar|NSApplicationPresentationAutoHideDock], NSFullScreenModeApplicationPresentationOptions,
                             nil];

    if ( [self isInFullScreenMode] ) {
        [self exitFullScreenModeWithOptions:options];
        [[self window] makeFirstResponder:self]; // we loose focus after exiting fullscreen
    } else {
        NSScreen* screen = [[self window] screen];
        [self enterFullScreenMode:screen withOptions:options];
    }
}



- (void)drawAtTime: (CGFloat)time
{
    draw( time );
    [[self openGLContext] flushBuffer]; // use this for double buffered GL context and glFlush() otherwise
}



@end
