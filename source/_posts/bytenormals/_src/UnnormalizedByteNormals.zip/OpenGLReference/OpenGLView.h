//
//  OpenGLView.h
//  OpenGLReference
//
//  Created by Michael Kwasnicki on 14.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <AppKit/AppKit.h>
#import <QuartzCore/CVDisplayLink.h>


// Extra work needs to be done to create shared contexts
// Refer to GLFullScreen

@interface OpenGLView : NSOpenGLView
{
    CVDisplayLinkRef displayLink;
    BOOL isAnimationRunning;
}

+ (NSOpenGLPixelFormat *)defaultPixelFormat;
- (id)initWithFrame: (NSRect)frameRect;
- (void)prepareOpenGL;
- (void)reshape;
- (void)drawRect: (NSRect)dirtyRect;


- (CVReturn)getFrameForTime: (const CVTimeStamp *)outputTime;

- (void)animationToggle;
- (void)animationStart;
- (void)animationStop;

- (void)fullscreenToggle;

- (void)drawAtTime: (CGFloat)time;

@end
